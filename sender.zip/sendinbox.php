<?php
/**
 * @Author: Eka Syahwan
 * @Date:   2018-08-29 08:57:41
 * @Last Modified by:   Eka Syahwan
 * @Last Modified time: 2018-09-02 05:44:54
*/



error_reporting(0);
define('SENDINBOX_PATH', realpath(dirname(__FILE__)));

require_once('Modules/SendinboxMailer/sendinboxMailer.php');
require_once('Modules/sdata-master/sdata-modules.php');
require_once('sendinbox-config.php');

class Sendinbox extends Sendinbox_config
{
	function __construct(){
		$this->sdata 		= new Sdata; 
		$this->SIBmodules 	= new SendinboxMailer( $this->sender() );
		$this->SIBmodules->cover();
		$this->Emailist 	= $this->SIBmodules->required();
		
		echo "\r\n[+] ".$this->SIBmodules->color("string","====================================================================")." [+]\r\n";
   		echo "[+] ".$this->SIBmodules->color("string","[ S E N D I N B O X - M A I L E R ]  - Emailist.org / Bmarket.or.id  ")."\r\n";
   		echo "[+] ".$this->SIBmodules->color("string","--------------------------------------------------------------------")."\r\n";
   		echo "[+] ".$this->SIBmodules->color("red","Selalu gunakan sendinbox yang legal. jika kamu masih numpang")."\r\n";
   		echo "[+] ".$this->SIBmodules->color("white","kami akan kasih kamu 20% diskon produk sendinbox")."\r\n";
   		echo "[+] ".$this->SIBmodules->color("white","suruh kawan mu (pembeli legal) untuk membelikan sendinbox untuk mu.")."\r\n";
   		echo "[+] ".$this->SIBmodules->color("white","untuk mu. itu lebih baik dari pada joinan sungkan minta update.")."\r\n";
   		echo "[+] ".$this->SIBmodules->color("green","** 1 kawan hanya bisa request 1x untuk diskon 20% **")."\r\n";
   		echo "[+] ".$this->SIBmodules->color("string","====================================================================")." [+]\r\n\n";

   		echo $this->SIBmodules->color("string","[sendunbox][N] --------- [EMAIL] -----------|----[SUBJECT]----|-STATUS-|------------[Server]--------------")."\r\n";
   		
		$this->run();
	}
	function run(){
		$config_server 	= $this->server();
		$config_sender 	= $this->sender();
		$config_message = $this->message();
		$config_header 	= $this->header();

		$list_total 	= count($this->Emailist);	
		$threads 		= $config_sender['config']['threads']; // don't change

		$emailist_split = array_chunk($this->Emailist, $threads);
		foreach ($emailist_split as $key => $getEmailist) {
			
			foreach ($getEmailist as $key => $putEmail) {

				######################################################################################################################
				# [ Random SET] #

				$server 			= $config_server['server']['multy'][array_rand($config_server['server']['multy'])];
				$subject 			= $config_message['message']['multy']['subject'][array_rand($config_message['message']['multy']['subject'])];
				$letter 			= $config_message['message']['multy']['letter'][array_rand($config_message['message']['multy']['letter'])];
				$from 				= $config_message['message']['multy']['from'][array_rand($config_message['message']['multy']['from'])];
				######################################################################################################################
				# [ encode SET & Alias ] #

				$subject 		= $this->SIBmodules->alias($subject , $putEmail);
				$from['name'] 	= $this->SIBmodules->alias($from['name'] , $putEmail);
				$from['email'] 	= $this->SIBmodules->alias($from['email'] , $putEmail);

				$subject 		= "=?".$config_sender['config']['charset']."?B?".base64_encode($subject)."?="; 
				$from['name'] 	= "=?".$config_sender['config']['charset']."?B?".base64_encode($from['name'])."?="; 
				
				$letter 		= file_get_contents(SENDINBOX_PATH.'/Letter/'.$letter);
				$letter 		= $this->SIBmodules->alias($letter , $putEmail);
				
				$letter 		= base64_encode($letter);
				######################################################################################################################
				
				$config_header['header']['Message-ID']  = '<'.time()."-".md5("sendinbox".rand(0,99999))."-".md5(phpversion()).'-{textrandom,4,1}@'.parse_url($server)['host'].'>';

				if( $config_sender['config']['domain_fromemail'] == true){
					$from['email'] = str_replace(explode("@", $from['email'])[1], parse_url($server)['host'], $from['email']);
				}

				$config_header['header']['From']  		= $from['name'].' <'.$from['email'].'>';

				foreach ($config_header as $key => $value) {
					foreach ($value as $key => $value) {
						$config_header['header'][$key] = $this->SIBmodules->alias($value , $putEmail);
					}
				}

				$this->arrayData[] = array(
					'url' 	=> array(
					'url' => $server, 
						'note' => array(
							'line'  	=> array_search($putEmail, $this->Emailist ),
							'email' 	=> $putEmail,
							'server' 	=> substr(parse_url($server)['host'], 0,20)." ... ",
						),
					), 
					'head' 	=> array(
						'post' => http_build_query(
							array(
								'letter' 	=> $letter,
								'to' 		=> $putEmail,
								'subject' 	=> $subject,
								'header' 	=> $config_header, 
								'config' 	=> $config_sender,
								'note' 		=> array(
									'line'  	=> array_search($putEmail, $this->Emailist ),
									'email' 	=> $putEmail,
									'server' 	=> substr(parse_url($server)['host'], 0,20)." ... ",
								),
							)
						),
					),
				);

				$list_total = ($list_total-1);
			}

			$respons = $this->send();
			$this->SIBmodules->extract_message($respons);
			unset($this->arrayData);
			if($list_total == 0){
				die($this->SIBmodules->color("bggreen","\r\n[Sendinbox] Pengiriman email telah selesai.\r\n"));
			}
			echo "[+] ".$this->SIBmodules->color("string","=======================[ DELAY ".$config_sender['config']['delay']." ]===========================")." [+]\r\n";
			sleep($config_sender['config']['delay']);

		}
	}
	function send(){

		foreach ($this->arrayData as $key => $arrayData) {
			$url[] 	= $arrayData['url'];
			$head[] = $arrayData['head'];
		}
		
		$request = $this->sdata->sdata($url , $head);

		$this->sdata->session_remove($request);

		unset($url); unset($head);
		
		foreach ($request as $key => $value) {
			$arrayNumber[$key] 	= $value['data']['note']['line'];
			$result[] = array(
				'email' => $value['data']['note']['email'], 
				'line' 	=> $value['data']['note']['line'], 
				'code' 	=> $value['info']['http_code'],
				'json' 	=> json_decode($value['respons'],true), 
			);
		}

		natsort($arrayNumber);
		sort($arrayNumber);
		
		return array($result);
	}
};
$Sendinbox = new Sendinbox;